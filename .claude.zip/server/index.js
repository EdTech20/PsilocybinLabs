// Entry point for the subscription-document web portal.
//
// Serves the static frontend (public/), merges collected subscriber data
// into the DOCX template (templates/template.docx), and — if DocuSign
// credentials are configured — sends the resulting document for e-signature.

const path = require('path');
const fs = require('fs');
const express = require('express');
require('dotenv').config();

const { generateFilledDocx } = require('./docgen');
const { sendForSignature, isDocusignConfigured } = require('./docusign');
const { validateSubmission } = require('./validation');

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(ROOT, 'public')));

app.get('/api/config', (req, res) => {
  res.json({
    docusignEnabled: isDocusignConfigured(),
    issuer: '1210954 B.C. Ltd.',
    offering: '$0.50 per Common Share — Private Placement',
  });
});

app.post('/api/generate', async (req, res) => {
  try {
    const errors = validateSubmission(req.body);
    if (errors.length) return res.status(400).json({ errors });

    const { buffer, filename } = await generateFilledDocx(req.body);

    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    );
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err) {
    console.error('generate error:', err);
    res.status(500).json({ error: err.message || 'Generation failed' });
  }
});

app.post('/api/send-for-signature', async (req, res) => {
  try {
    if (!isDocusignConfigured()) {
      return res.status(501).json({
        error:
          'DocuSign is not configured. Populate .env with DOCUSIGN_* credentials or download the DOCX and send manually.',
      });
    }

    const errors = validateSubmission(req.body);
    if (errors.length) return res.status(400).json({ errors });

    const { buffer, filename } = await generateFilledDocx(req.body);

    // Persist a copy for audit trail (required under securities recordkeeping)
    const auditPath = path.join(ROOT, 'generated', filename);
    fs.mkdirSync(path.dirname(auditPath), { recursive: true });
    fs.writeFileSync(auditPath, buffer);

    const result = await sendForSignature({
      documentBuffer: buffer,
      documentName: filename,
      subscriberName: req.body.subscriberName,
      subscriberEmail: req.body.subscriberEmail,
      issuerSignerName: process.env.ISSUER_SIGNER_NAME,
      issuerSignerEmail: process.env.ISSUER_SIGNER_EMAIL,
    });

    res.json({ ok: true, envelopeId: result.envelopeId, status: result.status });
  } catch (err) {
    console.error('sign error:', err);
    res.status(500).json({ error: err.message || 'DocuSign send failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Sub Doc Portal listening on http://localhost:${PORT}`);
  console.log(
    isDocusignConfigured()
      ? '  DocuSign: ENABLED'
      : '  DocuSign: not configured (download-only mode)'
  );
});
